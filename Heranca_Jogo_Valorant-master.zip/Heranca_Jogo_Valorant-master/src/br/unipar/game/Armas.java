package br.unipar.game;

public class Armas {
        private String Nome;
        private int Dano_Pernas;
        private int Dano_Corpo;
        private int Dano_Cabeca;
        private String Descricao;
        private String Tipo;
        private double Precisao;
        private double Alcance;
        private int Velocidade_Disparo;
        private int Cadencia;

        public String getNome() {
            return Nome;
        }

        public void setNome(String nome) {
            Nome = nome;
        }

        public int getDano_Pernas() {
            return Dano_Pernas;
        }

        public void setDano_Pernas(int dano_Pernas) {
            Dano_Pernas = dano_Pernas;
        }

        public int getDano_Corpo() {
            return Dano_Corpo;
        }

        public void setDano_Corpo(int dano_Corpo) {
            Dano_Corpo = dano_Corpo;
        }

        public int getDano_Cabeca() {
            return Dano_Cabeca;
        }

        public void setDano_Cabeca(int dano_Cabeca) {
            Dano_Cabeca = dano_Cabeca;
        }

        public String getDescricao() {
            return Descricao;
        }

        public void setDescricao(String descricao) {
            Descricao = descricao;
        }

        public String getTipo() {
            return Tipo;
        }

        public void setTipo(String tipo) {
            Tipo = tipo;
        }

        public double getPrecisao() {
            return Precisao;
        }

        public void setPrecisao(double precisao) {
            Precisao = precisao;
        }

        public double getAlcance() {
            return Alcance;
        }

        public void setAlcance(double alcance) {
            Alcance = alcance;
        }

        public int getVelocidade_Disparo() {
            return Velocidade_Disparo;
        }

        public void setVelocidade_Disparo(int velocidade_Disparo) {
            Velocidade_Disparo = velocidade_Disparo;
        }

        public int getCadencia() {
            return Cadencia;
        }

        public void setCadencia(int cadencia) {
            Cadencia = cadencia;
        }
    }

