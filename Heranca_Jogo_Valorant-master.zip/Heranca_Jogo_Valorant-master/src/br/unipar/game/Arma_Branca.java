package br.unipar.game;

public class Arma_Branca {

        private boolean Pegar_Arma;
        private String Inspecionar_Arma;

    public boolean isPegar_Arma() {
        return Pegar_Arma;
    }

    public void setPegar_Arma(boolean pegar_Arma) {
        Pegar_Arma = pegar_Arma;
    }

    public String getInspecionar_Arma() {
        return Inspecionar_Arma;
    }

    public void setInspecionar_Arma(String inspecionar_Arma) {
        Inspecionar_Arma = inspecionar_Arma;
    }
}
